package sample;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;

import java.awt.*;

public class Controller {

    @FXML
    javafx.scene.control.TextArea textArea;

    @FXML
    javafx.scene.control.TextField textField;

    public void sendMsg(){
        textArea.appendText(textField.getText() + "\n");
        textField.clear();
        textField.requestFocus();
    }

}
